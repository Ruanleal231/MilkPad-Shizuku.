package com.milk.pad;

interface IShellPad {
    void destroy() = 16777114;
    /** Returns an empty string on success, or the error text. */
    String send(String json) = 1;
}
