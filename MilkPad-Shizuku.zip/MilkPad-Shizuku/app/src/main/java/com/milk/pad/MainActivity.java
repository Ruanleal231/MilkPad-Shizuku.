package com.milk.pad;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);

        Button start = new Button(this);
        start.setText("Ligar controle");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                Toast.makeText(this, "Permita a sobreposição e volte", Toast.LENGTH_LONG).show();
                return;
            }
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                Toast.makeText(this, "Abra o Shizuku e inicie o serviço", Toast.LENGTH_LONG).show();
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(2);
                Toast.makeText(this, "Permita e toque em Ligar de novo", Toast.LENGTH_LONG).show();
                return;
            }
            startForegroundService(new Intent(this, PadService.class));
        });

        Button stop = new Button(this);
        stop.setText("Desligar controle");
        stop.setOnClickListener(v -> stopService(new Intent(this, PadService.class)));

        root.addView(start);
        root.addView(stop);
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }
}
