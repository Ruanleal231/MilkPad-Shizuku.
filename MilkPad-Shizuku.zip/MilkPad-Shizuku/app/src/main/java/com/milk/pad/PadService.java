package com.milk.pad;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import rikka.shizuku.Shizuku;

public class PadService extends Service {
    private final List<PadView> views = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager windows;
    private UInput pad;
    private Shizuku.UserServiceArgs args;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            if (pad != null) return;
            pad = new UInput(IShellPad.Stub.asInterface(binder), message -> main.post(() ->
                    Toast.makeText(PadService.this, message, Toast.LENGTH_LONG).show()));
            windows = getSystemService(WindowManager.class);
            layout();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Toast.makeText(PadService.this, "Shizuku desconectou", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "stop".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(
                new NotificationChannel("pad", "MilkPad", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, PadService.class).setAction("stop"), PendingIntent.FLAG_IMMUTABLE);
        startForeground(1, new Notification.Builder(this, "pad")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("MilkPad ligado")
                .setContentText("Toque para desligar")
                .setContentIntent(stop)
                .build());
        if (args == null) {
            args = new Shizuku.UserServiceArgs(
                    new ComponentName(getPackageName(), ShellPad.class.getName()))
                    .daemon(false)
                    .processNameSuffix("shell")
                    .version(1);
            Shizuku.bindUserService(args, connection);
        }
        return START_NOT_STICKY;
    }

    private void layout() {
        int bl = Gravity.BOTTOM | Gravity.LEFT, br = Gravity.BOTTOM | Gravity.RIGHT;
        int tl = Gravity.TOP | Gravity.LEFT, tr = Gravity.TOP | Gravity.RIGHT;

        stick("L", UInput.LX, UInput.LY, bl, 30, 90);
        stick("R", UInput.RX, UInput.RY, br, 180, 20);

        button("A", UInput.A, br, 70, 120);
        button("B", UInput.B, br, 20, 170);
        button("X", UInput.X, br, 120, 170);
        button("Y", UInput.Y, br, 70, 220);

        hat("▲", UInput.HAT_Y, -1, bl, 215, 100);
        hat("▼", UInput.HAT_Y, 1, bl, 215, 10);
        hat("◀", UInput.HAT_X, -1, bl, 170, 55);
        hat("▶", UInput.HAT_X, 1, bl, 260, 55);

        trigger("LT", UInput.LT, tl, 20, 50);
        button("LB", UInput.LB, tl, 85, 50);
        trigger("RT", UInput.RT, tr, 20, 50);
        button("RB", UInput.RB, tr, 85, 50);

        button("L3", UInput.L3, bl, 40, 245);
        button("R3", UInput.R3, br, 320, 20);
        button("SEL", UInput.SELECT, tl, 180, 10);
        button("STA", UInput.START, tr, 180, 10);
    }

    private void button(String label, int code, int gravity, int x, int y) {
        add(new PadView(this, label, down -> pad.key(code, down), null), 52, gravity, x, y);
    }

    private void trigger(String label, int axis, int gravity, int x, int y) {
        add(new PadView(this, label, down -> pad.abs(axis, down ? 255 : 0), null), 56, gravity, x, y);
    }

    private void hat(String label, int axis, int value, int gravity, int x, int y) {
        add(new PadView(this, label, down -> pad.abs(axis, down ? value : 0), null), 46, gravity, x, y);
    }

    private void stick(String label, int ax, int ay, int gravity, int x, int y) {
        add(new PadView(this, label, null, (vx, vy) -> pad.stick(ax, ay, vx, vy)), 130, gravity, x, y);
    }

    private void add(PadView view, int size, int gravity, int x, int y) {
        float d = getResources().getDisplayMetrics().density;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                Math.round(size * d), Math.round(size * d),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        p.x = Math.round(x * d);
        p.y = Math.round(y * d);
        windows.addView(view, p);
        views.add(view);
    }

    @Override
    public void onDestroy() {
        for (PadView view : views) windows.removeView(view);
        views.clear();
        if (pad != null) pad.close();
        if (args != null && Shizuku.pingBinder()) {
            Shizuku.unbindUserService(args, connection, true);
        }
        super.onDestroy();
    }
}
