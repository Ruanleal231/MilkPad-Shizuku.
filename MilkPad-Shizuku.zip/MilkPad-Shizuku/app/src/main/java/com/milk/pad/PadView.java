package com.milk.pad;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** One control: a button or an analog stick. */
final class PadView extends View {
    interface Press { void set(boolean down); }
    interface Move { void set(float x, float y); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String label;
    private final Press press;
    private final Move move;
    private boolean down;
    private float knobX, knobY;

    PadView(Context context, String label, Press press, Move move) {
        super(context);
        this.label = label;
        this.press = press;
        this.move = move;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy);
        paint.setColor(down && move == null ? 0xCC107C10 : 0x80202020);
        canvas.drawCircle(cx, cy, r, paint);
        if (move != null) {
            paint.setColor(0xB0FFFFFF);
            canvas.drawCircle(cx + knobX * r * 0.6f, cy + knobY * r * 0.6f, r * 0.38f, paint);
        }
        paint.setColor(move == null ? 0xFFFFFFFF : 0xFF202020);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(r * (label.length() > 2 ? 0.5f : 0.7f));
        float tx = cx + knobX * r * 0.6f, ty = cy + knobY * r * 0.6f;
        canvas.drawText(label, tx, ty - (paint.ascent() + paint.descent()) / 2f, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        boolean released = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL;
        if (move != null) {
            float r = Math.min(getWidth(), getHeight()) / 2f;
            float x = released ? 0 : (e.getX() - getWidth() / 2f) / (r * 0.75f);
            float y = released ? 0 : (e.getY() - getHeight() / 2f) / (r * 0.75f);
            float length = (float) Math.hypot(x, y);
            if (length > 1) {
                x /= length;
                y /= length;
            }
            knobX = x;
            knobY = y;
            move.set(x, y);
        } else if (action == MotionEvent.ACTION_DOWN) {
            down = true;
            press.set(true);
        } else if (released) {
            down = false;
            press.set(false);
        }
        invalidate();
        return true;
    }
}
