package com.milk.pad;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Runs inside the Shizuku shell process and owns the "uinput" command. */
public class ShellPad extends IShellPad.Stub {
    private Process process;
    private OutputStream out;
    private volatile String last = "";

    public ShellPad() {
    }

    @Override
    public synchronized String send(String json) {
        try {
            if (process == null) {
                process = new ProcessBuilder("uinput", "-").redirectErrorStream(true).start();
                out = process.getOutputStream();
                watch(process.getInputStream());
            }
            if (!process.isAlive()) return "uinput encerrou. " + last;
            out.write((json + "\n").getBytes(StandardCharsets.UTF_8));
            out.flush();
            return "";
        } catch (IOException e) {
            return "Falha no uinput: " + e.getMessage() + " " + last;
        }
    }

    private void watch(InputStream in) {
        new Thread(() -> {
            byte[] buffer = new byte[1024];
            try {
                int n;
                while ((n = in.read(buffer)) > 0) last = new String(buffer, 0, n, StandardCharsets.UTF_8);
            } catch (IOException ignored) {
            }
        }).start();
    }

    @Override
    public void destroy() {
        if (process != null) process.destroy();
        System.exit(0);
    }
}
