package com.milk.pad;

import android.os.RemoteException;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Virtual Xbox pad fed to the system "uinput" command through Shizuku. */
final class UInput {
    static final int EV_KEY = 1, EV_ABS = 3;
    static final int A = 304, B = 305, X = 307, Y = 308, LB = 310, RB = 311;
    static final int SELECT = 314, START = 315, GUIDE = 316, L3 = 317, R3 = 318;
    static final int LX = 0, LY = 1, LT = 2, RX = 3, RY = 4, RT = 5, HAT_X = 16, HAT_Y = 17;

    interface Failure { void report(String message); }

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final IShellPad shell;
    private final Failure failure;
    private boolean failed;
    private volatile boolean closed;

    UInput(IShellPad shell, Failure failure) {
        this.shell = shell;
        this.failure = failure;
        io.execute(this::open);
    }

    private void open() {
        StringBuilder abs = new StringBuilder();
        for (int code : new int[]{LX, LY, RX, RY}) axis(abs, code, -32768, 32767);
        for (int code : new int[]{LT, RT}) axis(abs, code, 0, 255);
        for (int code : new int[]{HAT_X, HAT_Y}) axis(abs, code, -1, 1);
        // 100/101/103 are UI_SET_EVBIT/KEYBIT/ABSBIT
        send("{\"id\":1,\"command\":\"register\",\"name\":\"Xbox 360 Controller\","
                + "\"vid\":1118,\"pid\":654,\"bus\":\"usb\",\"configuration\":["
                + "{\"type\":100,\"data\":[1,3]},"
                + "{\"type\":101,\"data\":[304,305,307,308,310,311,314,315,316,317,318]},"
                + "{\"type\":103,\"data\":[0,1,2,3,4,5,16,17]}],"
                + "\"ff_effects_max\":0,\"abs_info\":[" + abs + "]}");
        try {
            Thread.sleep(700);
        } catch (InterruptedException e) {
            return;
        }
        send("");
    }

    private static void axis(StringBuilder s, int code, int min, int max) {
        if (s.length() > 0) s.append(',');
        s.append("{\"code\":").append(code).append(",\"info\":{\"value\":0,\"minimum\":").append(min)
                .append(",\"maximum\":").append(max).append(",\"fuzz\":0,\"flat\":0,\"resolution\":0}}");
    }

    private void send(String json) {
        if (closed || failed) return;
        String error;
        try {
            error = shell.send(json);
        } catch (RemoteException e) {
            error = "Shizuku desconectou";
        }
        if (!error.isEmpty()) {
            failed = true;
            failure.report(error);
        }
    }

    private void inject(String events) {
        if (closed) return;
        io.execute(() -> send("{\"id\":1,\"command\":\"inject\",\"events\":[" + events + ",0,0,0]}"));
    }

    void key(int code, boolean down) {
        inject(EV_KEY + "," + code + "," + (down ? 1 : 0));
    }

    void abs(int code, int value) {
        inject(EV_ABS + "," + code + "," + value);
    }

    void stick(int codeX, int codeY, float x, float y) {
        inject(EV_ABS + "," + codeX + "," + Math.round(x * 32767) + ","
                + EV_ABS + "," + codeY + "," + Math.round(y * 32767));
    }

    void close() {
        closed = true;
        io.shutdown();
    }
}
